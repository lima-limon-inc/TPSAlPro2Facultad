package tp0

// Swap intercambia dos valores enteros.
func Swap(x *int, y *int) {
	*x, *y = *y, *x
}

// Maximo devuelve la posición del mayor elemento del arreglo, o -1 si el el arreglo es de largo 0. Si el máximo
// elemento aparece más de una vez, se debe devolver la primera posición en que ocurre.
func Maximo(vector []int) int {
	if len(vector) <= 0 {
		return -1
	}
	var max int = vector[0]
	var pos int = 0
	for i := 1; i < len(vector); i++ {
		if vector[i] > max {
			max = vector[i]
			pos = i
		}
	}
	return pos
}

// Comparar compara dos arreglos de longitud especificada.
// Devuelve -1 si el primer arreglo es menor que el segundo; 0 si son iguales; o 1 si el primero es el mayor.
// Un arreglo es menor a otro cuando al compararlos elemento a elemento, el primer elemento en el que difieren
// no existe o es menor.
func Comparar(vector1 []int, vector2 []int) int {
	var vector1Len, vector2Len int = len(vector1), len(vector2) // Calculo la longitud de cada uno de los arrays para despues poder usarlos

	for i := 0; i < vector1Len && i < vector2Len; i++ {
		switch {
		case vector1[i] < vector2[i]:
			return -1
		case vector1[i] > vector2[i]:
			return 1
		}
	}
	switch {
	case vector1Len > vector2Len:
		return 1
	case vector1Len < vector2Len:
		return -1
	}
	return 0
}

// Seleccion ordena el arreglo recibido mediante el algoritmo de selección.
func Seleccion(vector []int) {
	var long int = len(vector)
	for i := long - 1; i > 0; i-- {
		var maximo int = Maximo(vector[0 : i+1])
		Swap(&vector[i], &vector[maximo])
		//
		//		for j := i; j < long; j++ {
		//			if vector[j] < vector[minimo] {
		//				minimo = j
		//			}
		//		}
	}
}

// Suma devuelve la suma de los elementos de un arreglo. En caso de no tener elementos, debe devolver 0.
// Esta función debe implementarse de forma RECURSIVA. Se puede usar una función auxiliar (que sea
// la recursiva).
func Suma(vector []int) int {
	if len(vector) == 0 {
		return 0
	}
	return vector[0] + Suma(vector[1:])
}

// EsPalindromo devuelve si la cadena es un palíndromo. Es decir, si se lee igual al derecho que al revés.
// Esta función debe implementarse de forma RECURSIVA.
func EsPalindromo(cadena string) bool {
	if len(cadena) <= 1 {
		return true //Si se llega a esta condicion significa que nunca se dio que habia dos caracteres distintos
	}
	if cadena[0] != cadena[len(cadena)-1] {
		return false
	}

	return EsPalindromo(cadena[1 : len(cadena)-1])

}
